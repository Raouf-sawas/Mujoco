from .base import REGISTERED_ENVS, MujocoEnv

ALL_ENVS = REGISTERED_ENVS.keys()
