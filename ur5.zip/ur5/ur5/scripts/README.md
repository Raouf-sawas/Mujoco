Scripts
=======

This folder contains a collection of scripts to demonstrate the functionalities of robosuite. Check the documentation in the script files for detailed instructions.